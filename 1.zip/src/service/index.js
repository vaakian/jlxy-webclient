import jlxyHttp from './jlxyHttp';
import wxHttp from './wxHttp';

export {
  jlxyHttp,
  wxHttp
}