import interact from './interact';
import study from './study';
import mall from './mall';
import setting from './setting';


export {
  interact,
  study,
  mall,
  setting
}