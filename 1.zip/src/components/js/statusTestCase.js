const questions = [
  {
    title: '此处最多可容纳四识字，字数不同需要自动调整每个格子大小，保证页面美观。',
    answer: '答案最多容纳12字',
    status: 0,
    rate: 0.25
  },
  {
    title: '燕',
    answer: 'yan',
    status: 1,
    rate: 1.0
  },
  {
    title: '5+3=',
    answer: '8',
    status: 0,
    rate: 0.0
  },
  {
    title: '坐在井底看天。比喻眼界小，见识少。',
    answer: '坐井观天',
    status: 1,
    rate: 0.52
  },
  {
    title: '中华人民共和国成立于哪一年？',
    answer: '1949暖白',
    status: 1,
    rate: 0.8
  },
  {
    title: '离离原上草，下一句是？',
    answer: '一岁一枯荣',
    status: 0,
    rate: 0.4
  },
  {
    title: 'good',
    answer: '好的；优质的',
    status: 1,
    rate: 0.75
  },

]
export default [...questions, ...questions, ...questions];